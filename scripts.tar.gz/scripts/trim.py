from Bio import AlignIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Align import MultipleSeqAlignment

alignment = AlignIO.read("alignment.nex","nexus")

#train.annotations["molecule_type"] = "protein"


AlignIO.write([alignment],"alignment.fa","fasta")

AlignIO.convert("alignment.nex","nexus","alignement.fa","fasta")
#AlignIO.convert("alignment.fa","fasta","alignment.nex","nexus","protein")