from Bio import Phylo
from io import StringIO

tree = Phylo.read("tree.nwk", "newick")

def find_closest_species(tree, species1, species2):
    terminals = tree.get_terminals()
    node1 = None
    node2 = None
    for terminal in terminals:
        if terminal.name == species1:
            node1 = terminal
        elif terminal.name == species2:
            node2 = terminal
    if node1 is None or node2 is None:
        return None
    distance = tree.distance(node1, node2)
    return distance

min_distance = float('inf')
closest_pair = None

dist1 = find_closest_species(tree, "Homo_sapiens", "Pan_troglodytes")
dist2 = find_closest_species(tree, "Homo_sapiens", "Gorilla_gorilla_gorilla")
if dist1 < dist2:
    print("chimp")
if dist2 <= dist1:
    pring("gorilla")