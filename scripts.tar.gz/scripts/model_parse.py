import re

#run on a .iqtree file to return which model had the best BIC fit
filename = sys.argv[1]

with open(filename) as f:
    for line in f:
		if "Best-fit model according to BIC:" in line:
			model = re.search("\:(.*)",model)

print(model)