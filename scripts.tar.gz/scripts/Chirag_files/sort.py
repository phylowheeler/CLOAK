import os
from collections import OrderedDict

# Function to read a FASTA file and create a dictionary of sequences
def read_fasta_file(file_path):
    sequences = OrderedDict()
    with open(file_path, 'r') as file:
        lines = file.readlines()
        current_name = ''
        current_sequence = ''
        for line in lines:
            if line.startswith('>'):
                if current_name != '':
                    sequences[current_name] = current_sequence
                    current_sequence = ''
                current_name = line.strip()
            else:
                current_sequence += line.strip()
        if current_name != '':
            sequences[current_name] = current_sequence
    return sequences

# Function to write a dictionary of sequences to a new FASTA file in sorted order
def write_sorted_fasta_file(file_path, sequences):
    with open(file_path, 'w') as file:
        for name, sequence in sorted(sequences.items()):
            file.write(name + '\n')
            file.write(sequence + '\n')

# Iterate over each test_RV** folder in Tests
base_dir = '/home/u10/chatur/FinalTests_mergealign/Tests'
for root, dirs, files in os.walk(base_dir):
    for dir_name in dirs:
        if dir_name.startswith('test_RV'):
            test_rv_dir = os.path.join(root, dir_name)
            for root_bb, dirs_bb, files_bb in os.walk(test_rv_dir):
                for folder in dirs_bb:
                    if folder.startswith('BB'):
                        bb_folder = os.path.join(root_bb, folder)
                        files_to_process = [
                            "trimal_output.fasta"
                        ]
                        sequences_dict = OrderedDict()

                        # Read in the 9 files and create a dictionary of sequences
                        for file_name in files_to_process:
                            file_path = os.path.join(bb_folder, file_name)
                            sequences = read_fasta_file(file_path)
                            sequences_dict.update(sequences)

                        # Create a new file with sorted sequences
                        for file_name in files_to_process:
                            file_path = os.path.join(bb_folder, file_name)
                            new_file_name = 'sorted_' + file_name
                            new_file_path = os.path.join(bb_folder, new_file_name)
                            sequences = read_fasta_file(file_path)
                            write_sorted_fasta_file(new_file_path, sequences)
