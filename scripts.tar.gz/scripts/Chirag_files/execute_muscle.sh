#!/bin/bash

# Set the path to muscle.exe in the MaselLab2 directory
muscle_exe="C:/MaselLab2/muscle.exe"

# Iterate through the test_RV** folders
for test_folder in Tests/test_RV*; do
    # Iterate through the BB* folders inside each test_RV** folder
    for bb_folder in "$test_folder"/BB*; do
        # Find the .tfa file in the current BB* folder
        tfa_file=$(find "$bb_folder" -type f -name "*.tfa" -print -quit)

        # Create the stratified ensemble
        "$muscle_exe" -align "$tfa_file" -output "$bb_folder/stratified_ensemble.efa" -stratified

        # Create the muscle5 output file
        "$muscle_exe" -align "$tfa_file" -output "$bb_folder/muscle5_output.afa"

        # Change directory to the BB* folder
        cd "$bb_folder" || exit

        # Explode the stratified ensemble file
        "$muscle_exe" -efa_explode stratified_ensemble.efa

        # Change back to the original directory
        cd - || exit
    done
done
