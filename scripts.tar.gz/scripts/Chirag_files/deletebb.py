import shutil
import os

base_folder = "/home/u10/chatur/FinalTests_mergealign/Tests"

# Iterate over test_RV** folders
for test_folder in os.listdir(base_folder):
    if test_folder.startswith("test_RV"):
        test_folder_path = os.path.join(base_folder, test_folder)
        
        # Iterate over BB* folders
        for bb_folder in os.listdir(test_folder_path):
            bb_folder_path = os.path.join(test_folder_path, bb_folder)
            
            # Check if 4_rates.txt exists in the BB* folder
            rates_file_path = os.path.join(bb_folder_path, "trimal_rates.txt")
            if not os.path.isfile(rates_file_path):
                # Remove the non-empty BB* folder
                shutil.rmtree(bb_folder_path)
