#!/bin/bash
#
#SBATCH --job-name=muscle
#SBATCH --account=masel
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks=94
#SBATCH --mem-per-cpu=5gb
#SBATCH --time=12:00:00
#SBATCH --array 1-10

module load python/3.8
module load muscle

muscle -align train${SLURM_ARRAY_TASK_ID}.fa -output stratified_ensemble${SLURM_ARRAY_TASK_ID}.efa -stratified
mkdir ${SLURM_ARRAY_TASK_ID}_alignments
muscle -efa_explode stratified_ensemble${SLURM_ARRAY_TASK_ID}.efa -prefix ${SLURM_ARRAY_TASK_ID}_alignments/
python consensus6.py ${SLURM_ARRAY_TASK_ID}_alignments


echo "This job is running on node `uname -n`"
echo "This job is allocated ${SLURM_JOB_NUM_NODES} node(s), ${SLURM_JOB_CPUS_PER_NODE} core(s)/node and $((${SLURM_MEM_PER_CPU} / 1024 * ${SLURM_JOB_CPUS_PER_NODE})) Gigabytes of memory"
exit 0