#!/bin/bash

# Set the directory path
directory="C:/FinalTests/Tests"

# Change to the directory
cd "$directory"

# Iterate over test_RV** folders
for test_folder in test_RV*/; do
    # Iterate over BB* folders
    for bb_folder in "$test_folder"/BB*/; do
        cd "$bb_folder"

        # Compile the source code
        g++ -o msascorer msascorer.cpp Sequence.cpp

        # Run the commands for different files
        ./msascorer sorted_clustal_omega_output.fasta sorted_truth.fasta > clustal_omega_scores.txt
        ./msascorer sorted_intermediary4_result.fasta sorted_truth.fasta > 4_scores.txt
        ./msascorer sorted_intermediary7_result.fasta sorted_truth.fasta > 7_scores.txt
        ./msascorer sorted_intermediary16_result.fasta sorted_truth.fasta > 16_scores.txt
        ./msascorer sorted_mafft_output.fasta sorted_truth.fasta > mafft_scores.txt
        ./msascorer sorted_muscle5_output.afa sorted_truth.fasta > muscle5_scores.txt
        ./msascorer sorted_muscle5_output.afa.divvy.fas sorted_truth.fasta > muscle5_divvy_scores.txt
        ./msascorer sorted_muscle5_output.afa.partial.fas sorted_truth.fasta > muscle5_partial_filtering_scores.txt

        # Change back to the previous directory
        cd -
    done
done
