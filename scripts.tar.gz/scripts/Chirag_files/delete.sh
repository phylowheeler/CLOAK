#!/bin/bash

# Change directory to the parent folder
cd C:/FinalTests/Tests

# Iterate over each test_RV** folder
for test_folder in test_RV*/; do
    # Change directory to the test_RV** folder
    cd "$test_folder"
    
    # Iterate over each BB* folder
    for bb_folder in BB*/; do
        # Change directory to the BB* folder
        cd "$bb_folder"
        
        # Remove the specified files
        rm -f clustal_omega_scores.txt
        rm -f 4_scores.txt
        rm -f 7_scores.txt
        rm -f 16_scores.txt
        rm -f mafft_scores.txt
        rm -f muscle5_scores.txt
        rm -f muscle5_divvy_scores.txt
        rm -f muscle5_partial_filtering_scores.txt
        rm -f msascorer.exe
        rm -f msascorer
        
        # Change directory back to the parent folder of BB* folders
        cd ..
    done
    
    # Change directory back to the parent folder of test_RV** folders
    cd ..
done
