#!/bin/bash

# Go to the specified directory
cd /home/u10/chatur/FinalTests/Tests/test_RV11

# Loop through BB* folders
for folder in BB*/; do
  # Enter each BB* folder
  cd "$folder"
  
  # Check if a makefile exists
  if [ -f "Makefile" ]; then
    # Execute the make command
    make
  else
    echo "makefile not found in $folder"
  fi
  
  # Execute the divvier command
  ./divvier -mincol 1 -divvygap muscle5_output.afa
  ./divvier -partial -mincol 1 -divvygap muscle5_output.afa
  
  # Go back to the parent directory
  cd ..
done