#!/bin/bash

source_folder="/home/u10/chatur/FinalTests_mergealign/trimal-trimAl"
target_parent_folder="/home/u10/chatur/FinalTests_mergealign/Tests"

# Copy files to BB* folders in all test_RV** folders
for test_folder in "$target_parent_folder"/test_RV*; do
  if [ -d "$test_folder" ]; then
    for bb_folder in "$test_folder"/BB*; do
      if [ -d "$bb_folder" ]; then
        # Use rsync to copy the entire directory structure
        rsync -av "$source_folder"/ "$bb_folder"/
      fi
    done
  fi
done
