import os

def calculate_rates(true_pos, false_pos, total_ref):
    true_pos_rate = true_pos / total_ref
    false_pos_rate_total_ref = false_pos / total_ref
    false_pos_rate_tp_fp = false_pos / (true_pos + false_pos)
    return true_pos_rate, false_pos_rate_total_ref, false_pos_rate_tp_fp

# Specify the required files
required_files = ['clustal_omega_scores.txt','16_scores.txt','4_scores.txt','7_scores.txt','mafft_scores.txt','mergealign_scores.txt','muscle5_scores.txt','muscle5_divvy_scores.txt','muscle5_partial_filtering_scores.txt','trimal_scores.txt','truth_scores.txt']

# Set the base directory path
base_dir = '/home/u10/chatur/FinalTests_mergealign/Tests'

# Iterate over test_RV** folders
for test_rv_folder in os.listdir(base_dir):
    if not test_rv_folder.startswith('test_RV'):
        continue

    # Iterate over BB* folders
    for bb_folder in os.listdir(os.path.join(base_dir, test_rv_folder)):
        if not bb_folder.startswith('BB'):
            continue

        # Check if all required files exist
        files_exist = all(os.path.isfile(os.path.join(base_dir, test_rv_folder, bb_folder, file)) for file in required_files)
        if not files_exist:
            continue

        # Flag to indicate if all scores files meet the expected format
        all_scores_valid = True

        # Process each scores file
        for scores_file in required_files:
            scores_filepath = os.path.join(base_dir, test_rv_folder, bb_folder, scores_file)
            rates_file = scores_file.replace('_scores.txt', '_rates.txt')
            rates_filepath = os.path.join(base_dir, test_rv_folder, bb_folder, rates_file)

            try:
                with open(scores_filepath, 'r') as scores, open(rates_filepath, 'w') as rates:
                    # Read the scores from the file
                    lines = scores.readlines()
                    true_pos = int(lines[1].split('=')[1].strip())
                    false_pos = int(lines[2].split('=')[1].strip())
                    total_ref = int(lines[4].split('=')[1].strip())

                    # Calculate the rates
                    true_pos_rate, false_pos_rate_total_ref, false_pos_rate_tp_fp = calculate_rates(true_pos, false_pos, total_ref)

                    # Write the rates to the rates file
                    rates.write(f'TruePosRateTotalRef={true_pos_rate}\n')
                    rates.write(f'FalsePosRateTotalRef={false_pos_rate_total_ref}\n')
                    rates.write(f'FalsePosRateTPFP={false_pos_rate_tp_fp}\n')

            except (IndexError, ValueError):
                # Set the flag to False if any scores file does not follow the expected format
                all_scores_valid = False
                print(f"Error: Unexpected format in scores file '{scores_filepath}'")
                break  # Stop processing other files if there's an error

        # Remove all rates files if any scores file does not meet the expected format
        if not all_scores_valid:
            for rates_file in required_files:
                rates_filepath = os.path.join(base_dir, test_rv_folder, bb_folder, rates_file.replace('_scores.txt', '_rates.txt'))
                if os.path.exists(rates_filepath):
                    os.remove(rates_filepath)
