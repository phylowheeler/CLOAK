import os
from Bio import SeqIO

# Directory containing the BB* folders
input_directory = r"C:\MaselLab2\Tests"

# Recursively search for input.msf files in BB* folders
for root, dirs, files in os.walk(input_directory):
    for file in files:
        if file == "input.msf":
            msf_file = os.path.join(root, file)
            output_file = os.path.join(root, "truth.fasta")

            # Read the MSF file and convert it to FASTA
            records = SeqIO.parse(msf_file, "msf")
            SeqIO.write(records, output_file, "fasta")

            print(f"Converted {msf_file} to FASTA: {output_file}")
