#!/bin/bash

# Delete folders named ordered_fasta_files_
find "C:/MaselLab2/Tests" -type d -name "ordered_fasta_files_*" -exec rm -r {} +
