#!/bin/bash

test_folder="/home/u10/chatur/FinalTests_mergealign/Tests/test_RV11"

# Iterate over each BB* folder in the test_RV11 folder
for bb_folder in "$test_folder"/BB*; do
    # Copy muscle5_output.afa to BB*/source_trimal
    cp "$bb_folder"/muscle5_output.afa "$bb_folder"/source_trimal

    # Change to the source_trimal directory
    cd "$bb_folder"/source_trimal

    # Generate trimal_output.fasta using the makefile
    make

    # Run trimal to create trimal_output.fasta
    ./trimal -fasta -in muscle5_output.afa -out trimal_output.fasta

    # Copy trimal_output.fasta from source_trimal to BB*
    cp trimal_output.fasta ..

    # Go back to the parent directory
    cd ../../
done
