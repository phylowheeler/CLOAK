#!/bin/bash

count_4_rates=0
count_7_rates=0
count_16_rates=0
count_clustal_omega_rates=0
count_mafft_rates=0
count_muscle5_divvy_rates=0
count_muscle5_partial_filtering_rates=0
count_muscle5_rates=0

# Iterate over test_RV** folders
for test_rv_folder in C:/FinalTests/Tests/test_RV*; do
  # Iterate over BB* folders
  for bb_folder in "$test_rv_folder"/BB*; do
    if [ -f "$bb_folder/4_rates.txt" ]; then
      ((count_4_rates++))
    fi
    if [ -f "$bb_folder/7_rates.txt" ]; then
      ((count_7_rates++))
    fi
    if [ -f "$bb_folder/16_rates.txt" ]; then
      ((count_16_rates++))
    fi
    if [ -f "$bb_folder/clustal_omega_rates.txt" ]; then
      ((count_clustal_omega_rates++))
    fi
    if [ -f "$bb_folder/mafft_rates.txt" ]; then
      ((count_mafft_rates++))
    fi
    if [ -f "$bb_folder/muscle5_divvy_rates.txt" ]; then
      ((count_muscle5_divvy_rates++))
    fi
    if [ -f "$bb_folder/muscle5_partial_filtering_rates.txt" ]; then
      ((count_muscle5_partial_filtering_rates++))
    fi
    if [ -f "$bb_folder/muscle5_rates.txt" ]; then
      ((count_muscle5_rates++))
    fi
  done
done

echo "Number of 4_rates.txt files: $count_4_rates"
echo "Number of 7_rates.txt files: $count_7_rates"
echo "Number of 16_rates.txt files: $count_16_rates"
echo "Number of clustal_omega_rates.txt files: $count_clustal_omega_rates"
echo "Number of mafft_rates.txt files: $count_mafft_rates"
echo "Number of muscle5_divvy_rates.txt files: $count_muscle5_divvy_rates"
echo "Number of muscle5_partial_filtering_rates.txt files: $count_muscle5_partial_filtering_rates"
echo "Number of muscle5_rates.txt files: $count_muscle5_rates"
