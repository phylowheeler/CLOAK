#!/bin/bash

# Delete ordered_fasta_files_intermediary4 folders
find "C:/MaselLab2/Tests" -type d -name "ordered_fasta_files_intermediary4" -exec rm -r {} +

# Delete ordered_fasta_files_intermediary7 folders
find "C:/MaselLab2/Tests" -type d -name "ordered_fasta_files_intermediary7" -exec rm -r {} +

# Delete ordered_fasta_files_intermediary16 folders
find "C:/MaselLab2/Tests" -type d -name "ordered_fasta_files_intermediary16" -exec rm -r {} +

# Delete intermediary16_result.fasta files
find "C:/MaselLab2/Tests" -type f -name "intermediary16_result.fasta" -exec rm {} +

# Delete intermediary4_result.fasta files
find "C:/MaselLab2/Tests" -type f -name "intermediary4_result.fasta" -exec rm {} +

# Delete intermediary7_result.fasta files
find "C:/MaselLab2/Tests" -type f -name "intermediary7_result.fasta" -exec rm {} +

find "C:/MaselLab2/Tests" -type f -name "_result.fasta" -exec rm {} +
