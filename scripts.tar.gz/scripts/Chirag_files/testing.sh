#!/bin/bash

# Create the Tests directory
mkdir -p ./Tests

# Loop through each RV folder
for rv_folder in ./Balibase/bb3_release/RV*/; do
    # Get the RV folder name
    rv_folder_name=${rv_folder%*/}
    rv_folder_name=${rv_folder_name##*/}

    # Loop through each file in the RV folder
    for rv_file in "$rv_folder"*; do
        # Get the RV file extension
        rv_file_ext="${rv_file##*.}"

        if [[ "$rv_file_ext" == "tfa" ]]; then
            # Get the RV file name
            rv_file_name=$(basename "$rv_file" .tfa)

            # Create the test folder for this RV file
            test_folder_name=${rv_file_name##*/}
            mkdir -p "./Tests/test_$rv_folder_name/$test_folder_name"

            # Copy the .tfa file to the test folder
            cp "$rv_file" "./Tests/test_$rv_folder_name/$test_folder_name/"

        elif [[ "$rv_file_ext" == "msf" ]]; then
            # Get the RV file name
            rv_file_name=$(basename "$rv_file" .msf)

            # Create the test folder for this RV file
            test_folder_name=${rv_file_name##*/}
            mkdir -p "./Tests/test_$rv_folder_name/$test_folder_name"

            # Copy the .msf file to the test folder
            cp "$rv_file" "./Tests/test_$rv_folder_name/$test_folder_name/"

            # Convert the .msf file to fasta format and name it ground_truth_*.fasta
            if [[ "$rv_file" =~ \.msf$ ]]; then
            awk '/^ Name: /{gsub(/[ \t]+$/, "", $2); seq[$2]=""; next}
                /^[A-Z]/ {for (i in seq) seq[i]=seq[i]$0}
                END {for (i in seq) print ">"i"\n"seq[i]}' "$rv_file" > "$test_folder/ground_truth_${test_folder_name}.fasta"

            fi

        fi
    done

    # Copy muscle.exe and consensus6.py to the test folder
    for test_folder in ./Tests/test_"$rv_folder_name"/*/; do
        cp muscle.exe "$test_folder"
        cp consensus6.py "$test_folder"
    done
done

echo "Done"
