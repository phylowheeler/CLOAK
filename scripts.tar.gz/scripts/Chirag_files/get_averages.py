import os

root_dir = "/home/u10/chatur/FinalTests_mergealign"
average_dir = os.path.join(root_dir, "Average")

# Create the 'Average' directory if it doesn't exist
if not os.path.exists(average_dir):
    os.makedirs(average_dir)

# Initialize variables to store cumulative values
count_4_rates = 0
total_TruePosRateTotalRef_4 = 0.0
total_FalsePosRateTotalRef_4 = 0.0
total_FalsePosRateTPFP_4 = 0.0

count_7_rates = 0
total_TruePosRateTotalRef_7 = 0.0
total_FalsePosRateTotalRef_7 = 0.0
total_FalsePosRateTPFP_7 = 0.0

count_16_rates = 0
total_TruePosRateTotalRef_16 = 0.0
total_FalsePosRateTotalRef_16 = 0.0
total_FalsePosRateTPFP_16 = 0.0

count_clustal_omega_rates = 0
total_TruePosRateTotalRef_clustal_omega = 0.0
total_FalsePosRateTotalRef_clustal_omega = 0.0
total_FalsePosRateTPFP_clustal_omega = 0.0

count_mafft_rates = 0
total_TruePosRateTotalRef_mafft = 0.0
total_FalsePosRateTotalRef_mafft = 0.0
total_FalsePosRateTPFP_mafft = 0.0

count_muscle5_divvy_rates = 0
total_TruePosRateTotalRef_muscle5_divvy = 0.0
total_FalsePosRateTotalRef_muscle5_divvy = 0.0
total_FalsePosRateTPFP_muscle5_divvy = 0.0

count_muscle5_partial_filtering_rates = 0
total_TruePosRateTotalRef_muscle5_partial_filtering = 0.0
total_FalsePosRateTotalRef_muscle5_partial_filtering = 0.0
total_FalsePosRateTPFP_muscle5_partial_filtering = 0.0

count_muscle5_rates = 0
total_TruePosRateTotalRef_muscle5 = 0.0
total_FalsePosRateTotalRef_muscle5 = 0.0
total_FalsePosRateTPFP_muscle5 = 0.0

# Iterate over test_RV** folders
for test_rv_folder in os.scandir(os.path.join(root_dir, "Tests")):
    if test_rv_folder.is_dir() and test_rv_folder.name.startswith("test_RV"):
        # Iterate over BB* folders
        for bb_folder in os.scandir(test_rv_folder.path):
            if bb_folder.is_dir() and bb_folder.name.startswith("BB"):
                # Process 4_rates.txt
                rates_4_file = os.path.join(bb_folder.path, "4_rates.txt")
                if os.path.isfile(rates_4_file):
                    count_4_rates += 1
                    with open(rates_4_file, "r") as file_4:
                        lines_4 = file_4.readlines()
                        total_TruePosRateTotalRef_4 += float(lines_4[0].split("=")[1])
                        total_FalsePosRateTotalRef_4 += float(lines_4[1].split("=")[1])
                        total_FalsePosRateTPFP_4 += float(lines_4[2].split("=")[1])

                # Process 7_rates.txt
                rates_7_file = os.path.join(bb_folder.path, "7_rates.txt")
                if os.path.isfile(rates_7_file):
                    count_7_rates += 1
                    with open(rates_7_file, "r") as file_7:
                        lines_7 = file_7.readlines()
                        total_TruePosRateTotalRef_7 += float(lines_7[0].split("=")[1])
                        total_FalsePosRateTotalRef_7 += float(lines_7[1].split("=")[1])
                        total_FalsePosRateTPFP_7 += float(lines_7[2].split("=")[1])

                # Process 16_rates.txt
                rates_16_file = os.path.join(bb_folder.path, "16_rates.txt")
                if os.path.isfile(rates_16_file):
                    count_16_rates += 1
                    with open(rates_16_file, "r") as file_16:
                        lines_16 = file_16.readlines()
                        total_TruePosRateTotalRef_16 += float(lines_16[0].split("=")[1])
                        total_FalsePosRateTotalRef_16 += float(lines_16[1].split("=")[1])
                        total_FalsePosRateTPFP_16 += float(lines_16[2].split("=")[1])

                # Process clustal_omega_rates.txt
                rates_clustal_omega_file = os.path.join(bb_folder.path, "clustal_omega_rates.txt")
                if os.path.isfile(rates_clustal_omega_file):
                    count_clustal_omega_rates += 1
                    with open(rates_clustal_omega_file, "r") as file_clustal_omega:
                        lines_clustal_omega = file_clustal_omega.readlines()
                        total_TruePosRateTotalRef_clustal_omega += float(lines_clustal_omega[0].split("=")[1])
                        total_FalsePosRateTotalRef_clustal_omega += float(lines_clustal_omega[1].split("=")[1])
                        total_FalsePosRateTPFP_clustal_omega += float(lines_clustal_omega[2].split("=")[1])

                # Process mafft_rates.txt
                rates_mafft_file = os.path.join(bb_folder.path, "mafft_rates.txt")
                if os.path.isfile(rates_mafft_file):
                    count_mafft_rates += 1
                    with open(rates_mafft_file, "r") as file_mafft:
                        lines_mafft = file_mafft.readlines()
                        total_TruePosRateTotalRef_mafft += float(lines_mafft[0].split("=")[1])
                        total_FalsePosRateTotalRef_mafft += float(lines_mafft[1].split("=")[1])
                        total_FalsePosRateTPFP_mafft += float(lines_mafft[2].split("=")[1])

                # Process muscle5_divvy_rates.txt
                rates_muscle5_divvy_file = os.path.join(bb_folder.path, "muscle5_divvy_rates.txt")
                if os.path.isfile(rates_muscle5_divvy_file):
                    count_muscle5_divvy_rates += 1
                    with open(rates_muscle5_divvy_file, "r") as file_muscle5_divvy:
                        lines_muscle5_divvy = file_muscle5_divvy.readlines()
                        total_TruePosRateTotalRef_muscle5_divvy += float(lines_muscle5_divvy[0].split("=")[1])
                        total_FalsePosRateTotalRef_muscle5_divvy += float(lines_muscle5_divvy[1].split("=")[1])
                        total_FalsePosRateTPFP_muscle5_divvy += float(lines_muscle5_divvy[2].split("=")[1])

                # Process muscle5_partial_filtering_rates.txt
                rates_muscle5_partial_filtering_file = os.path.join(bb_folder.path, "muscle5_partial_filtering_rates.txt")
                if os.path.isfile(rates_muscle5_partial_filtering_file):
                    count_muscle5_partial_filtering_rates += 1
                    with open(rates_muscle5_partial_filtering_file, "r") as file_muscle5_partial_filtering:
                        lines_muscle5_partial_filtering = file_muscle5_partial_filtering.readlines()
                        total_TruePosRateTotalRef_muscle5_partial_filtering += float(lines_muscle5_partial_filtering[0].split("=")[1])
                        total_FalsePosRateTotalRef_muscle5_partial_filtering += float(lines_muscle5_partial_filtering[1].split("=")[1])
                        total_FalsePosRateTPFP_muscle5_partial_filtering += float(lines_muscle5_partial_filtering[2].split("=")[1])

                # Process muscle5_rates.txt
                rates_muscle5_file = os.path.join(bb_folder.path, "muscle5_rates.txt")
                if os.path.isfile(rates_muscle5_file):
                    count_muscle5_rates += 1
                    with open(rates_muscle5_file, "r") as file_muscle5:
                        lines_muscle5 = file_muscle5.readlines()
                        total_TruePosRateTotalRef_muscle5 += float(lines_muscle5[0].split("=")[1])
                        total_FalsePosRateTotalRef_muscle5 += float(lines_muscle5[1].split("=")[1])
                        total_FalsePosRateTPFP_muscle5 += float(lines_muscle5[2].split("=")[1])

# Calculate average values
average_TruePosRateTotalRef_4 = total_TruePosRateTotalRef_4 / count_4_rates
average_FalsePosRateTotalRef_4 = total_FalsePosRateTotalRef_4 / count_4_rates
average_FalsePosRateTPFP_4 = total_FalsePosRateTPFP_4 / count_4_rates

average_TruePosRateTotalRef_7 = total_TruePosRateTotalRef_7 / count_7_rates
average_FalsePosRateTotalRef_7 = total_FalsePosRateTotalRef_7 / count_7_rates
average_FalsePosRateTPFP_7 = total_FalsePosRateTPFP_7 / count_7_rates

average_TruePosRateTotalRef_16 = total_TruePosRateTotalRef_16 / count_16_rates
average_FalsePosRateTotalRef_16 = total_FalsePosRateTotalRef_16 / count_16_rates
average_FalsePosRateTPFP_16 = total_FalsePosRateTPFP_16 / count_16_rates

average_TruePosRateTotalRef_clustal_omega = total_TruePosRateTotalRef_clustal_omega / count_clustal_omega_rates
average_FalsePosRateTotalRef_clustal_omega = total_FalsePosRateTotalRef_clustal_omega / count_clustal_omega_rates
average_FalsePosRateTPFP_clustal_omega = total_FalsePosRateTPFP_clustal_omega / count_clustal_omega_rates

average_TruePosRateTotalRef_mafft = total_TruePosRateTotalRef_mafft / count_mafft_rates
average_FalsePosRateTotalRef_mafft = total_FalsePosRateTotalRef_mafft / count_mafft_rates
average_FalsePosRateTPFP_mafft = total_FalsePosRateTPFP_mafft / count_mafft_rates

average_TruePosRateTotalRef_muscle5_divvy = total_TruePosRateTotalRef_muscle5_divvy / count_muscle5_divvy_rates
average_FalsePosRateTotalRef_muscle5_divvy = total_FalsePosRateTotalRef_muscle5_divvy / count_muscle5_divvy_rates
average_FalsePosRateTPFP_muscle5_divvy = total_FalsePosRateTPFP_muscle5_divvy / count_muscle5_divvy_rates

average_TruePosRateTotalRef_muscle5_partial_filtering = total_TruePosRateTotalRef_muscle5_partial_filtering / count_muscle5_partial_filtering_rates
average_FalsePosRateTotalRef_muscle5_partial_filtering = total_FalsePosRateTotalRef_muscle5_partial_filtering / count_muscle5_partial_filtering_rates
average_FalsePosRateTPFP_muscle5_partial_filtering = total_FalsePosRateTPFP_muscle5_partial_filtering / count_muscle5_partial_filtering_rates

average_TruePosRateTotalRef_muscle5 = total_TruePosRateTotalRef_muscle5 / count_muscle5_rates
average_FalsePosRateTotalRef_muscle5 = total_FalsePosRateTotalRef_muscle5 / count_muscle5_rates
average_FalsePosRateTPFP_muscle5 = total_FalsePosRateTPFP_muscle5 / count_muscle5_rates

# Save average values to the 'Average' directory
with open(os.path.join(average_dir, "average_4_rates.txt"), "w") as average_4:
    average_4.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_4}\n")
    average_4.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_4}\n")
    average_4.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_4}\n")

with open(os.path.join(average_dir, "average_7_rates.txt"), "w") as average_7:
    average_7.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_7}\n")
    average_7.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_7}\n")
    average_7.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_7}\n")

with open(os.path.join(average_dir, "average_16_rates.txt"), "w") as average_16:
    average_16.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_16}\n")
    average_16.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_16}\n")
    average_16.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_16}\n")

with open(os.path.join(average_dir, "average_clustal_omega_rates.txt"), "w") as average_clustal_omega:
    average_clustal_omega.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_clustal_omega}\n")
    average_clustal_omega.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_clustal_omega}\n")
    average_clustal_omega.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_clustal_omega}\n")

with open(os.path.join(average_dir, "average_mafft_rates.txt"), "w") as average_mafft:
    average_mafft.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_mafft}\n")
    average_mafft.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_mafft}\n")
    average_mafft.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_mafft}\n")

with open(os.path.join(average_dir, "average_muscle5_divvy_rates.txt"), "w") as average_muscle5_divvy:
    average_muscle5_divvy.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_muscle5_divvy}\n")
    average_muscle5_divvy.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_muscle5_divvy}\n")
    average_muscle5_divvy.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_muscle5_divvy}\n")

with open(os.path.join(average_dir, "average_muscle5_partial_filtering_rates.txt"), "w") as average_muscle5_partial_filtering:
    average_muscle5_partial_filtering.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_muscle5_partial_filtering}\n")
    average_muscle5_partial_filtering.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_muscle5_partial_filtering}\n")
    average_muscle5_partial_filtering.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_muscle5_partial_filtering}\n")

with open(os.path.join(average_dir, "average_muscle5_rates.txt"), "w") as average_muscle5:
    average_muscle5.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_muscle5}\n")
    average_muscle5.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_muscle5}\n")
    average_muscle5.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_muscle5}\n")
    
    
# Create the 'Average' directory if it doesn't exist
if not os.path.exists(average_dir):
    os.makedirs(average_dir)

# Initialize variables to store cumulative values
count_mergealign_rates = 0
total_TruePosRateTotalRef_mergealign = 0.0
total_FalsePosRateTotalRef_mergealign = 0.0
total_FalsePosRateTPFP_mergealign = 0.0

# Iterate over test_RV** folders
for test_rv_folder in os.scandir(os.path.join(root_dir, "Tests")):
    if test_rv_folder.is_dir() and test_rv_folder.name.startswith("test_RV"):
        # Iterate over BB* folders
        for bb_folder in os.scandir(test_rv_folder.path):
            if bb_folder.is_dir() and bb_folder.name.startswith("BB"):
                # Process mergealign_rates.txt
                rates_mergealign_file = os.path.join(bb_folder.path, "mergealign_rates.txt")
                if os.path.isfile(rates_mergealign_file):
                    count_mergealign_rates += 1
                    with open(rates_mergealign_file, "r") as file_mergealign:
                        lines_mergealign = file_mergealign.readlines()
                        total_TruePosRateTotalRef_mergealign += float(lines_mergealign[0].split("=")[1])
                        total_FalsePosRateTotalRef_mergealign += float(lines_mergealign[1].split("=")[1])
                        total_FalsePosRateTPFP_mergealign += float(lines_mergealign[2].split("=")[1])

# Calculate average values
average_TruePosRateTotalRef_mergealign = total_TruePosRateTotalRef_mergealign / count_mergealign_rates
average_FalsePosRateTotalRef_mergealign = total_FalsePosRateTotalRef_mergealign / count_mergealign_rates
average_FalsePosRateTPFP_mergealign = total_FalsePosRateTPFP_mergealign / count_mergealign_rates

# Save average values to the 'Average' directory
with open(os.path.join(average_dir, "average_mergealign_rates.txt"), "w") as average_mergealign:
    average_mergealign.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_mergealign}\n")
    average_mergealign.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_mergealign}\n")
    average_mergealign.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_mergealign}\n")






# Initialize variables to store cumulative values
count_trimal_rates = 0
total_TruePosRateTotalRef_trimal = 0.0
total_FalsePosRateTotalRef_trimal = 0.0
total_FalsePosRateTPFP_trimal = 0.0

# Iterate over test_RV** folders
for test_rv_folder in os.scandir(os.path.join(root_dir, "Tests")):
    if test_rv_folder.is_dir() and test_rv_folder.name.startswith("test_RV"):
        # Iterate over BB* folders
        for bb_folder in os.scandir(test_rv_folder.path):
            if bb_folder.is_dir() and bb_folder.name.startswith("BB"):
                # Process mergealign_rates.txt
                rates_trimal_file = os.path.join(bb_folder.path, "trimal_rates.txt")
                if os.path.isfile(rates_trimal_file):
                    count_trimal_rates += 1
                    with open(rates_trimal_file, "r") as file_trimal:
                        lines_trimal = file_trimal.readlines()
                        total_TruePosRateTotalRef_trimal += float(lines_trimal[0].split("=")[1])
                        total_FalsePosRateTotalRef_trimal += float(lines_trimal[1].split("=")[1])
                        total_FalsePosRateTPFP_trimal += float(lines_trimal[2].split("=")[1])

# Calculate average values
average_TruePosRateTotalRef_trimal = total_TruePosRateTotalRef_trimal / count_trimal_rates
average_FalsePosRateTotalRef_trimal = total_FalsePosRateTotalRef_trimal / count_trimal_rates
average_FalsePosRateTPFP_trimal = total_FalsePosRateTPFP_trimal / count_trimal_rates

# Save average values to the 'Average' directory
with open(os.path.join(average_dir, "average_trimal_rates.txt"), "w") as average_trimal:
    average_trimal.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_trimal}\n")
    average_trimal.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_trimal}\n")
    average_trimal.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_trimal}\n")
    
    
    
    
    
    
    
# Initialize variables to store cumulative values
count_truth_rates = 0
total_TruePosRateTotalRef_truth = 0.0
total_FalsePosRateTotalRef_truth = 0.0
total_FalsePosRateTPFP_truth = 0.0

# Iterate over test_RV** folders
for test_rv_folder in os.scandir(os.path.join(root_dir, "Tests")):
    if test_rv_folder.is_dir() and test_rv_folder.name.startswith("test_RV"):
        # Iterate over BB* folders
        for bb_folder in os.scandir(test_rv_folder.path):
            if bb_folder.is_dir() and bb_folder.name.startswith("BB"):
                # Process mergealign_rates.txt
                rates_truth_file = os.path.join(bb_folder.path, "truth_rates.txt")
                if os.path.isfile(rates_truth_file):
                    count_truth_rates += 1
                    with open(rates_truth_file, "r") as file_truth:
                        lines_truth = file_truth.readlines()
                        total_TruePosRateTotalRef_truth += float(lines_truth[0].split("=")[1])
                        total_FalsePosRateTotalRef_truth += float(lines_truth[1].split("=")[1])
                        total_FalsePosRateTPFP_truth += float(lines_truth[2].split("=")[1])

# Calculate average values
average_TruePosRateTotalRef_truth = total_TruePosRateTotalRef_truth / count_truth_rates
average_FalsePosRateTotalRef_truth = total_FalsePosRateTotalRef_truth / count_truth_rates
average_FalsePosRateTPFP_truth = total_FalsePosRateTPFP_truth / count_truth_rates

# Save average values to the 'Average' directory
with open(os.path.join(average_dir, "average_truth_rates.txt"), "w") as average_truth:
    average_truth.write(f"TruePosRateTotalRef={average_TruePosRateTotalRef_truth}\n")
    average_truth.write(f"FalsePosRateTotalRef={average_FalsePosRateTotalRef_truth}\n")
    average_truth.write(f"FalsePosRateTPFP={average_FalsePosRateTPFP_truth}\n")
    