#!/bin/bash

# Change directory to the Tests folder
cd C:/MaselLab2/Tests || exit

# Find all test_RV** folders
for folder in test_RV*/; do
    # Change directory to the current test_RV** folder
    cd "$folder" || exit

    # Find all subfolders (BB*) and rename the MSF files
    for subfolder in BB*/; do
        cd "$subfolder" || exit
        msf_file=$(ls *.msf)
        if [[ ! -z "$msf_file" ]]; then
            mv "$msf_file" input.msf
        fi
        cd ..
    done

    cd ..
done
