#!/bin/bash

# Delete files named consensus6.py
find "C:/MaselLab2/Tests" -type f -name "consensus6.py" -delete
