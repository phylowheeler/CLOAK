#!/bin/bash

source_dir="/home/u10/chatur/FinalTests/mergealign.py"
target_dir="/home/u10/chatur/FinalTests/Tests"

# Iterate over test_RV** folders
for test_folder in "$target_dir"/test_RV**; do
    if [[ -d "$test_folder" ]]; then
        # Iterate over BB* folders within each test_RV** folder
        for bb_folder in "$test_folder"/BB*; do
            if [[ -d "$bb_folder" ]]; then
                cp "$source_dir" "$bb_folder"
            fi
        done
    fi
done
