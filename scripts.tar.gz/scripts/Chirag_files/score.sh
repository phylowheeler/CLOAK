#!/bin/bash

# Set the base directory
base_dir="/home/u10/chatur/FinalTests_mergealign/Tests"

# Iterate over test_RV** folders
for test_dir in "$base_dir"/test_RV*/; do
    # Iterate over BB* folders
    for bb_dir in "$test_dir"/BB*/; do
        # Change directory to the BB* folder
        cd "$bb_dir"

        # Compile msascorer program
        g++ -o msascorer MSAscorer.cpp Sequence.cpp

        # Run msascorer command if output files don't exist
        if [ ! -f "clustal_omega_scores.txt" ]; then
            ./msascorer sorted_clustal_omega_output.fasta sorted_truth.fasta > clustal_omega_scores.txt
        fi
        if [ ! -f "16_scores.txt" ]; then
            ./msascorer sorted_intermediary16_result.fasta sorted_truth.fasta > 16_scores.txt
        fi
        if [ ! -f "4_scores.txt" ]; then
            ./msascorer sorted_intermediary4_result.fasta sorted_truth.fasta > 4_scores.txt
        fi
        if [ ! -f "7_scores.txt" ]; then
            ./msascorer sorted_intermediary7_result.fasta sorted_truth.fasta > 7_scores.txt
        fi
        if [ ! -f "mafft_scores.txt" ]; then
            ./msascorer sorted_mafft_output.fasta sorted_truth.fasta > mafft_scores.txt
        fi
        if [ ! -f "mergealign_scores.txt" ]; then
            ./msascorer sorted_mergealign_output.fasta sorted_truth.fasta > mergealign_scores.txt
        fi
        if [ ! -f "muscle5_scores.txt" ]; then
            ./msascorer sorted_muscle5_output.afa sorted_truth.fasta > muscle5_scores.txt
        fi
        if [ ! -f "muscle5_divvy_scores.txt" ]; then
            ./msascorer sorted_muscle5_output.afa.divvy.fas sorted_truth.fasta > muscle5_divvy_scores.txt
        fi
        if [ ! -f "muscle5_partial_filtering_scores.txt" ]; then
            ./msascorer sorted_muscle5_output.afa.partial.fas sorted_truth.fasta > muscle5_partial_filtering_scores.txt
        fi
        if [ ! -f "trimal_scores.txt" ]; then
            ./msascorer sorted_trimal_output.fasta sorted_truth.fasta > trimal_scores.txt
        fi
        if [ ! -f "truth_scores.txt" ]; then
            ./msascorer sorted_truth.fasta sorted_truth.fasta > truth_scores.txt
        fi

        # Change directory back to the base directory
        cd "$base_dir"
    done
done
