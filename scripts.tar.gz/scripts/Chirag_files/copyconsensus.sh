#!/bin/bash

# Change directory to C:/MaselLab2/Tests
cd "C:/MaselLab2/Tests"

# Set the path to consensus6.py file
consensus6_path="C:/MaselLab2/consensus6.py"

# Iterate through each test_RV** folder
for rv_folder in test_RV*/; do
  # Enter the test_RV** folder
  cd "$rv_folder"

  # Iterate through each BB* folder
  for bb_folder in BB*/; do
    # Enter the BB* folder
    cd "$bb_folder"

    # Copy consensus6.py into the current BB* folder
    cp "$consensus6_path" .

    # Exit the BB* folder
    cd ..
  done

  # Exit the test_RV** folder
  cd ..
done
