#!/bin/bash

# Change directory to MaselLab2/Tests
cd "C:/MaselLab2/Tests"

# Iterate through each test_RV** folder
for rv_folder in test_RV*/; do
  # Enter the test_RV** folder
  cd "$rv_folder"

  # Iterate through each BB* folder
  for bb_folder in BB*/; do
    # Enter the BB* folder
    cd "$bb_folder"

    # First run: using intermediary16 as input, save output as result16.fasta
    python "C:/MaselLab2/Tests/$rv_folder$bb_folder/consensus6.py" "C:/MaselLab2/Tests/$rv_folder$bb_folder/intermediary16/" -o result16.fasta

    # Second run: using intermediary7 as input, save output as result7.fasta
    python "C:/MaselLab2/Tests/$rv_folder$bb_folder/consensus6.py" "C:/MaselLab2/Tests/$rv_folder$bb_folder/intermediary7/" -o result7.fasta

    # Third run: using intermediary4 as input, save output as result4.fasta
    python "C:/MaselLab2/Tests/$rv_folder$bb_folder/consensus6.py" "C:/MaselLab2/Tests/$rv_folder$bb_folder/intermediary4/" -o result4.fasta

    # Exit the BB* folder
    cd ..
  done

  # Exit the test_RV** folder
  cd ..
done
