#!/bin/bash

# Set the base directory
base_dir="/home/u10/chatur/FinalTests/Tests"

# Iterate over test_RV** folders
for test_dir in "$base_dir"/test_RV*/; do
    # Iterate over BB* folders
    for bb_dir in "$test_dir"/BB*/; do
        # Check if intermediary16 folder exists
        if [ -d "$bb_dir/intermediary16" ]; then
            # Run mergealign.py with input and output filenames
            python2 mergealign.py -a "$bb_dir/ordered_fasta_files_intermediary16" -f "$bb_dir/mergealign_output.fasta"
        fi
    done
done
