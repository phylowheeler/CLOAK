#!/usr/bin/env python3

"""
MergeAlign algorithm for creating consensus multiple sequence alignments
For a list of options, run:
>> python3 mergeAlign.py -h
"""

import os
import sys
import getopt


class Node:
    """A position in alignment space with edges to the previous nodes in all alignments"""

    def __init__(self):
        self.previous_nodes = {}
        self.path_score = 0
        self.path_length = 0
        self.path_average = 0
        self.best_previous_node = None


def combineMultipleAlignments(alignment_names):
    """Combine all alignments in a folder into a single alignment.
    Takes a list of file paths to FASTA alignments.
    Returns a consensus alignment as a dictionary and a list of column scores."""
    
    # Read alignments
    alignments = [parseFASTA(alignment) for alignment in alignment_names]

    # Open the first file and remove gaps to get original sequences in a dictionary
    original_sequences = dict([(name, seq.replace('-', '')) for name, seq in alignments[0].items()])
    sequence_names = list(original_sequences.keys())

    # Convert dictionaries of sequences to lists of indices
    indices = [[convertSequenceToIndices(alignment[seq]) for seq in sequence_names] for alignment in alignments]

    # Convert alignments into list of coordinates
    coordinates = [list(zip(*alignment)) for alignment in indices]

    # Move through coordinates, generating paths of nodes through the alignments and finding best alignment
    nodes = createNodes(coordinates)
    final_coordinates, scores = scoreNodes(nodes, len(coordinates))
    final_alignment = convertListOfCoordinatesToSequences(final_coordinates, original_sequences)

    return final_alignment, scores


def parseFASTA(filename):
    """Read file in FASTA format.
    Return a dictionary with key=sequence name, value=sequence."""

    try:
        with open(filename, 'r') as f:
            sequences = {}
            seq_id = None

            for line in f:
                line = line.strip()
                if line.startswith('>'):
                    seq_id = line[1:]
                    sequences[seq_id] = ''
                elif seq_id is not None:
                    sequences[seq_id] += line

            if not sequences:
                print(f"{filename} contains no sequences")
                sys.exit(2)

            return sequences

    except IOError:
        print(f"Unable to open file {filename}")
        sys.exit(2)


def convertSequenceToIndices(sequence):
    """Convert a sequence to a list of amino acid indices.
    Gaps are converted to the index of the preceding amino acid."""

    indices = []
    i = 0

    for aa in sequence:
        if aa != '-':
            i += 1
        indices.append(i)

    return indices


def convertIndicesToSequence(indices, original_sequence):
    """Convert list of indices back to the original sequence plus gaps"""

    sequence = ''
    previous_i = 0

    for i in indices:
        if i != previous_i:
            sequence += original_sequence[i - 1]
        else:
            sequence += '-'
        previous_i = i

    return sequence


def convertListOfCoordinatesToSequences(final_coordinates, original_sequences):
    """Convert a list of coordinates in alignment space into an alignment using a passed dictionary of sequences."""

    seq_names = list(original_sequences.keys())
    alignment = {}

    for i, seq_name in enumerate(seq_names):
        indices = [x[i] for x in final_coordinates]
        alignment[seq_name] = convertIndicesToSequence(indices, original_sequences[seq_name])

    return alignment


def createNodes(coordinates, num_alignments):
    """Create the nodes for a path through the coordinates"""

    # Get dimensions of coordinates
    m = num_alignments  # Number of alignments
    n = len(coordinates[0])  # Length of each alignment

    # Initialize list of nodes
    nodes = [[Node() for _ in range(n)] for _ in range(m)]

    # Set up edges between nodes
    for i in range(1, m):
        for j in range(1, n):
            for k in range(num_alignments):
                previous_i = coordinates[i][j][k]
                previous_j = coordinates[i - 1][j][k]
                previous_node = nodes[i - 1][previous_j]

                if previous_i in nodes[i][j].previous_nodes:
                    if previous_node.path_score + 1 < nodes[i][j].path_score:
                        nodes[i][j].previous_nodes[previous_i] = previous_node
                else:
                    nodes[i][j].previous_nodes[previous_i] = previous_node

            # Add current score to the node
            nodes[i][j].path_score = nodes[i][j].previous_nodes[nodes[i][j].path_length][j].path_score + 1
            nodes[i][j].path_length = j
            nodes[i][j].path_average = nodes[i][j].path_score / nodes[i][j].path_length

            # Find previous node with the best score
            nodes[i][j].best_previous_node = min(nodes[i][j].previous_nodes.values(), key=lambda x: x.path_score)

    return nodes



def scoreNodes(nodes, num_alignments):
    """Score the nodes and find the optimal alignment"""

    # Get dimensions of nodes
    m = len(nodes)  # number of alignments
    n = len(nodes[0])  # length of each alignment

    # Find best node in the last row
    best_last_node = min(nodes[m - 1], key=lambda x: x.path_score)

    # Follow the pointers back to the start, marking which nodes are on the path
    final_coordinates = [[0] * num_alignments for _ in range(n)]
    scores = []

    for i in range(n - 1, -1, -1):
        node = best_last_node
        while node is not None:
            final_coordinates[i][node.path_length] = 1
            scores.append(node.path_average)
            node = node.best_previous_node

    return final_coordinates, scores


def saveFASTA(alignment, filename):
    """Save alignment in FASTA format."""

    try:
        with open(filename, 'w') as f:
            for name, seq in alignment.items():
                f.write(f">{name}\n")
                f.write(f"{seq}\n")
        print(f"Alignment saved as {filename}")
    except IOError:
        print(f"Unable to write to file {filename}")


def printUsage():
    """Print usage information"""
    print("""Usage:
    mergeAlign.py -i <input_folder> -o <output_file>
    mergeAlign.py -h

Options:
    -i, --input <input_folder>      Folder containing alignment files in FASTA format
    -o, --output <output_file>      File to save the final merged alignment in FASTA format
    -h, --help                      Display this usage information""")


def main(argv):
    """Main function"""

    input_folder = ''
    output_file = ''

    try:
        opts, _ = getopt.getopt(argv, "hi:o:", ["help", "input=", "output="])
    except getopt.GetoptError:
        printUsage()
        sys.exit(2)

    for opt, arg in opts:
        if opt in ("-h", "--help"):
            printUsage()
            sys.exit()
        elif opt in ("-i", "--input"):
            input_folder = arg
        elif opt in ("-o", "--output"):
            output_file = arg

    if input_folder == '' or output_file == '':
        print("Input folder and output file are required.")
        printUsage()
        sys.exit(2)

    alignment_names = [os.path.join(input_folder, file) for file in os.listdir(input_folder) if file.endswith('.fasta')]
    if not alignment_names:
        print(f"No FASTA files found in {input_folder}")
        sys.exit(2)

    alignment, scores = combineMultipleAlignments(alignment_names)
    saveFASTA(alignment, output_file)


if __name__ == "__main__":
    main(sys.argv[1:])
