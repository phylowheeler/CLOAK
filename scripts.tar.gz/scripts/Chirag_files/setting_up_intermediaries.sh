#!/bin/bash

# Change directory to MaselLab2/Tests
cd C:/MaselLab2/Tests

# Iterate through each test_RV** folder
for rv_folder in test_RV*/; do
  # Enter the test_RV** folder
  cd "$rv_folder"

  # Iterate through each BB* folder
  for bb_folder in BB*/; do
    # Enter the BB* folder
    cd "$bb_folder"

    # Create intermediary16 folder and move the 16 files into it
    mkdir -p intermediary16
    mv abc.0 abc.1 abc.2 abc.3 acb.0 acb.1 acb.2 acb.3 bca.0 bca.1 bca.2 bca.3 none.0 none.1 none.2 none.3 intermediary16/

    # Create intermediary7 folder and copy select files from intermediary16
    mkdir -p intermediary7
    cp intermediary16/{none.0,none.1,none.2,none.3,abc.0,acb.0,bca.0} intermediary7/

    # Create intermediary4 folder and copy select files from intermediary16
    mkdir -p intermediary4
    cp intermediary16/{none.0,abc.1,acb.2,bca.3} intermediary4/

    # Exit the BB* folder
    cd ..
  done

  # Exit the test_RV** folder
  cd ..
done
