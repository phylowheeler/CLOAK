from cogent3 import make_tree
import os
import csv

tr1 = load_tree("data/test.tree")
distances = []

for filename in os.listdir("/path/to/dir/"):
    if filename.endswith(".nwk") or filename.endswith(".tree"): 
    	tr2 = load_tree(filename)
        lrm_distance = tr1.tree_distance(tr2, method="lin_rajan_moret")
        distances = distances.append(lrm_distance)
    else:
        continue

with open(..., 'w', newline='') as distances:
     wr = csv.writer(distances, quoting=csv.QUOTE_ALL)
     wr.writerow(distances)