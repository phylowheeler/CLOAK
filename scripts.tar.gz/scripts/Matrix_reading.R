library(devtools)
library(patchwork)
library(sem)
library(ggfortify)
library(ggrepel)
library(expm)
library(ca)
library(FactoMineR)


readR2Q <- function(filename) {
  R = readMoments(filename, diag=F)
  pi = R[nrow(R), 1:(ncol(R)-1)]
  R = R[1:(nrow(R)-1), 1:(ncol(R)-1)]
  R = (R + t(R))
  Q=R
  for (j in 1:20){Q[,j] = Q[,j]*pi[j]}
  # Q = pi * R
  diag(Q) <- 0
  diag(Q) <- -apply(Q, 1, sum)
  miu = -sum(pi*diag(Q))
  # normalise the matrix
  Q = Q/miu
  return(rbind(Q, pi))
}

readR <- function(filename) {
  # read lower-diagonal matrix
  R = readMoments(filename, diag=F)
  pi = R[nrow(R), 1:(ncol(R)-1)]
  R = R[1:(nrow(R)-1), 1:(ncol(R)-1)]
  
  # make R symmetric
  R = (R + t(R))
  Q = pi * R
  diag(Q) <- 0
  diag(Q) <- -apply(Q, 1, sum)
  miu = -sum(pi*diag(Q))
  # normalise the matrix
  R = R/miu
  return(rbind(R, pi))
}

filenames = c("Q.mammal","Q.mammal_cloak","Q.mammal_divvier","Q.mammal_cloak","Q.mammal_GTRPMIX","Q.mammal_guidance","Q.mammal_taper","QC.mammal")
allQ = NULL
allF = NULL
allR = NULL
for (f in filenames) {
  print(f)
  R_pi = readR(f)
  R = R_pi[1:(nrow(R_pi)-1),]
  pi = R_pi[nrow(R_pi),]

  allR = rbind(allR, R[lower.tri(R)])
  allF = rbind(allF, pi)

  Q_pi = readR2Q(f)
  Q = Q_pi[1:(nrow(Q_pi)-1),]
  allQ = rbind(allQ, as.vector(t(Q)))
}
rownames(allR) <- filenames
rownames(allF) <- filenames
rownames(allQ) <- filenames