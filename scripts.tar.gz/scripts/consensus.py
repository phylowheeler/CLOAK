#!/usr/bin/env python3
"""
Script to compute consensus phylogenetic trees from multiple input trees.
"""

from Bio import Phylo
from Bio.Phylo.Consensus import (
    strict_consensus,
    majority_consensus,
    adam_consensus
)
from io import StringIO
import sys
from pathlib import Path


class ConsensusTreeBuilder:
    def __init__(self, tree_file, file_format="newick"):
        self.tree_file = tree_file
        self.file_format = file_format
        self.trees = []
        self.load_trees()
    
    def load_trees(self):
        try:
            self.trees = list(Phylo.parse(self.tree_file, self.file_format))
        except Exception as e:
            sys.exit(1)
    
    def get_consensus(self):
        if len(self.trees) < 2:
            print("Need at least 2 trees for consensus")
            return None
        
        try:
            consensus = strict_consensus(self.trees)
            return consensus
        except Exception as e:
            return None
    
    def save_tree(self, tree, output_file, output_format="newick"):
        try:
            Phylo.write(tree, output_file, output_format)

def main():
    """Main execution function."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Compute consensus phylogenetic trees from multiple input trees"
    )
    parser.add_argument(
        "input_file",
        help="Input file containing multiple phylogenetic trees"
    )
    parser.add_argument(
        "-f", "--format",
        default="newick",
        choices=["newick", "nexus", "phyloxml", "nexml", "cdao"],
        help="Input file format (default: newick)"
    )
    parser.add_argument(
        "-o", "--output",
        help="Output file for consensus tree"
    )
    parser.add_argument(
        "-of", "--output-format",
        default="newick",
        choices=["newick", "nexus", "phyloxml"],
        help="Output file format (default: newick)"
    )
    
    args = parser.parse_args()
    
    if not Path(args.input_file).exists():
        sys.exit(1)
    
    builder = ConsensusTreeBuilder(args.input_file, args.format)
    
    consensus_tree = builder.get_strict_consensus()
    builder.save_tree(consensus_tree, args.output, args.output_format)

if __name__ == "__main__":
    main()