library(devtools)
library(patchwork)
library(sem)
library(ggfortify)
library(ggrepel)
library(expm)
library(ca)
library(FactoMineR)

#function to parse and normalize a Q matrix file
readR2Q <- function(filename) {
  R = readMoments(filename, diag=F)
  pi = R[nrow(R), 1:(ncol(R)-1)]
  R = R[1:(nrow(R)-1), 1:(ncol(R)-1)]
  R = (R + t(R))
  Q=R
  for (j in 1:20){Q[,j] = Q[,j]*pi[j]}
  # Q = pi * R
  diag(Q) <- 0
  diag(Q) <- -apply(Q, 1, sum)
  miu = -sum(pi*diag(Q))
  # normalise the matrix
  Q = Q/miu
  return(rbind(Q, pi))
}

#function to get just normalized exchangeabilities
readR <- function(filename) {
  # read lower-diagonal matrix
  R = readMoments(filename, diag=F)
  pi = R[nrow(R), 1:(ncol(R)-1)]
  R = R[1:(nrow(R)-1), 1:(ncol(R)-1)]
  
  # make R symmetric
  R = (R + t(R))
  Q = pi * R
  diag(Q) <- 0
  diag(Q) <- -apply(Q, 1, sum)
  miu = -sum(pi*diag(Q))
  # normalise the matrix
  R = R/miu
  return(R)
}

#list of all files in your analysis
filenames = c("Q.insect","Q.insect_buried","Q.insect_surface","Q.mammal","Q.mammal_buried","Q.mammal_surface","Q.plant","Q.plant_buried","Q.plant_surface","Q.yeast","Q.yeast_buried","Q.yeast_surface")

#Q.matrix values
allQ = NULL
#excahngeability values
allR = NULL
#equilibrium frequency values
allF = NULL
#transition probability matrix values
allT = NULL

for (f in filenames) {
	print(f)
	Q_pi = readR2Q(f)
	Q = Q_pi[1:(nrow(Q_pi)-1),]
	pi = Q_pi[nrow(Q_pi),]
	R = readR(f)

	allQ = rbind(allQ, as.vector(t(Q)))
	allR = rbind(allR,as.vector(t(R)))
	allF = rbind(allF, pi)

	#get transition probability matrix
	transition = expm(Q)
	allT = rbind(allT,as.vector(t(transition)))
}

#if you want to color code by species
species = c("insect","insect","insect","mammal","mammal","mammal","plant","plant","plant","yeast","yeast","yeast")
options(ggrepel.max.overlaps = Inf)

#use list of values you want for the PCA
df_pca <- prcomp(allR)
df_out <- as.data.frame(df_pca$x)
#group points by species
df_out$group = species
#get variance percentages
percentage <- round(df_pca$sdev / sum(df_pca$sdev) * 100, 2)
percentage <- paste( colnames(df_out), "(", paste( as.character(percentage), "%", ")", sep="") )
#plot script
ggplot(df_out,aes(x=PC1,y=PC2, color=group, label = filenames)) + 
  theme(legend.position="none", legend.title = element_blank(),text = element_text(size=30)) + 
  geom_point() +
  geom_text_repel(size=5) +
  xlab(percentage[1]) +
  ylab(percentage[2]) +
  #use axis limits to get a square plot including all points
  xlim(-8,12) +
  ylim(-8,12)
#save figure as jpg
ggsave(filename = "surface_burried.jpg", width=5, height=5, units="in")