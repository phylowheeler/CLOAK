#!/bin/bash
#
#SBATCH --job-name=muscle
#SBATCH --partition=windfall
#SBATCH --nodes=1
#SBATCH --ntasks=20
#SBATCH --mem-per-cpu=6gb
#SBATCH --time=10:00:00
#SBATCH --array=1-1000

module load muscle/5.1.0

for file in training/*.fa; do muscle -align "$file" -stratified -output "${file%.*}/ensemble.@.fa"; done