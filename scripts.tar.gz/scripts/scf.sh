#!/bin/bash

ALN_FILE=
TREE_FILE=

iqtree2 -te concat.treefile -s ALN_FILE -te TREE_FILE --scfl 100 -m QC.mammal+F --prefix concord