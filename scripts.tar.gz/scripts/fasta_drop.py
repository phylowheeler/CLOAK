import sys
from Bio import SeqIO

drop_cutoff = 1
to_write = []

for record in SeqIO.parse(sys.argv[1], "fasta"):
    seq = record.seq
    seqLen = len(record)
    gap_count = 0
    for i in range(seqLen):
        if seq[i]=='-' or seq[i]=='X':
            gap_count += 1
    if (gap_count/float(seqLen)) < drop_cutoff:
        to_write.append(record)
        
SeqIO.write(to_write, sys.argv[1], "fasta")