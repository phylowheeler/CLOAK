#!/bin/bash
#
#SBATCH --job-name=bird_model_finder
#SBATCH --account=masel
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --mem-per-cpu=4gb
#SBATCH --time=12:00:00
#SBATCH --array=0

for f in ./*.fa; do iqtree2 -s "$f" -m MF -mset JTT,WAG,LG,Q.pfam,Q.plant,Q.bird,Q.mammal,Q.insect,Q.yeast; done

